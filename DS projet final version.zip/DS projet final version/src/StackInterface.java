interface StackInterface{
    public void push(Object newEntry);
    public Object pop();
    public Object peek();
    public boolean isEmpty();
    public void clear();
    public void display();
}